# DB-GPT-SQL-Execution-Plugin
> Still under developement

## Commands
- `db_sql_executor`,  exectue sql in database and return results of execution

## Plugin Installation Steps

1. **Clone or download the plugin repository:**
   Clone the plugin repository, or download the repository as a zip file.
2. 
3. **Install the plugin's dependencies:**
   Navigate to the plugin's folder in your terminal, and run the following command to install any required dependencies:

   ``` shell
      pip install -r requirements.txt
   ```

4. **Package the plugin as a Zip file:**
   If you cloned the repository, compress the plugin folder as a Zip file.

5. **Copy the plugin's Zip file:**
   Place the plugin's Zip file in the `plugins` folder of the DB-GPT repository.

6. **Allowlist the plugin (optional):**
   Add the plugin's class name to the `ALLOWLISTED_PLUGINS` in the `.env` file to avoid being prompted with a warning when loading the plugin:

   ``` shell
   ALLOWLISTED_PLUGINS=DbGPTGenericDB
   ```

   If the plugin is not allowlisted, you will be warned before it's loaded.

## Configure Enviroments
Add following configuration properties in `Auth-GPT/.env`

DB_HOST="127.0.0.1"
DB_PORT=3306
DB_USER="<db-user>"
DB_PASSWORD="<db-password>"
DB_DATABASE="<database-name>"
``` 默认MYSQL
DB_TYPE="MYSQL" 
``` 